//package com.example.mohamadreza.musicmediaplayer.model;
//
//import org.greenrobot.greendao.annotation.Entity;
//import org.greenrobot.greendao.annotation.Id;
//import org.greenrobot.greendao.annotation.ToOne;
//import org.greenrobot.greendao.annotation.Generated;
//
//@Entity
//public class LyricLine {
//
//    @Id(autoincrement = true)
//    private long mId;
//    private long mLyricId;
//    private String mLine;
//    private int mShowTime;
//    @Generated(hash = 1407589380)
//    public LyricLine(long mId, long mLyricId, String mLine, int mShowTime) {
//        this.mId = mId;
//        this.mLyricId = mLyricId;
//        this.mLine = mLine;
//        this.mShowTime = mShowTime;
//    }
//    @Generated(hash = 746649597)
//    public LyricLine() {
//    }
//    public long getMId() {
//        return this.mId;
//    }
//    public void setMId(long mId) {
//        this.mId = mId;
//    }
//    public long getMLyricId() {
//        return this.mLyricId;
//    }
//    public void setMLyricId(long mLyricId) {
//        this.mLyricId = mLyricId;
//    }
//    public String getMLine() {
//        return this.mLine;
//    }
//    public void setMLine(String mLine) {
//        this.mLine = mLine;
//    }
//    public int getMShowTime() {
//        return this.mShowTime;
//    }
//    public void setMShowTime(int mShowTime) {
//        this.mShowTime = mShowTime;
//    }
//
//}
