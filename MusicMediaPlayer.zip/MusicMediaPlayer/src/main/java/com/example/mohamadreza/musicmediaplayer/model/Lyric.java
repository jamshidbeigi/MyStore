//package com.example.mohamadreza.musicmediaplayer.model;
//
//import org.greenrobot.greendao.annotation.Entity;
//import org.greenrobot.greendao.annotation.Id;
//import org.greenrobot.greendao.annotation.ToMany;
//
//import java.util.List;
//import org.greenrobot.greendao.annotation.Generated;
//import org.greenrobot.greendao.DaoException;
//
//@Entity
//public class Lyric {
//
//    @Id(autoincrement = true)
//    private long mId;
//    @ToMany(referencedJoinProperty = "mLyricId")
//    private List<LyricLine> mLines;
//    /** Used to resolve relations */
//    @Generated(hash = 2040040024)
//    private transient DaoSession daoSession;
//    /** Used for active entity operations. */
//    @Generated(hash = 1685673968)
//    private transient LyricDao myDao;
//
//    public Lyric(List<LyricLine> lines) {
//        mLines = lines;
//    }
//
//    @Generated(hash = 734891265)
//    public Lyric(long mId) {
//        this.mId = mId;
//    }
//
//    @Generated(hash = 2083827090)
//    public Lyric() {
//    }
//
//    public List<LyricLine> getLines() {
//        return mLines;
//    }
//
//    public void setLines(List<LyricLine> lines) {
//        mLines = lines;
//    }
//
//    public long getId() {
//        return mId;
//    }
//
//    public void setId(long id) {
//        mId = id;
//    }
//
//    /**
//     * To-many relationship, resolved on first access (and after reset).
//     * Changes to to-many relations are not persisted, make changes to the target entity.
//     */
//    @Generated(hash = 1309116197)
//    public List<LyricLine> getMLines() {
//        if (mLines == null) {
//            final DaoSession daoSession = this.daoSession;
//            if (daoSession == null) {
//                throw new DaoException("Entity is detached from DAO context");
//            }
//            LyricLineDao targetDao = daoSession.getLyricLineDao();
//            List<LyricLine> mLinesNew = targetDao._queryLyric_MLines(mId);
//            synchronized (this) {
//                if (mLines == null) {
//                    mLines = mLinesNew;
//                }
//            }
//        }
//        return mLines;
//    }
//
//    /** Resets a to-many relationship, making the next get call to query for a fresh result. */
//    @Generated(hash = 1300372825)
//    public synchronized void resetMLines() {
//        mLines = null;
//    }
//
//    /**
//     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#delete(Object)}.
//     * Entity must attached to an entity context.
//     */
//    @Generated(hash = 128553479)
//    public void delete() {
//        if (myDao == null) {
//            throw new DaoException("Entity is detached from DAO context");
//        }
//        myDao.delete(this);
//    }
//
//    /**
//     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#refresh(Object)}.
//     * Entity must attached to an entity context.
//     */
//    @Generated(hash = 1942392019)
//    public void refresh() {
//        if (myDao == null) {
//            throw new DaoException("Entity is detached from DAO context");
//        }
//        myDao.refresh(this);
//    }
//
//    /**
//     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#update(Object)}.
//     * Entity must attached to an entity context.
//     */
//    @Generated(hash = 713229351)
//    public void update() {
//        if (myDao == null) {
//            throw new DaoException("Entity is detached from DAO context");
//        }
//        myDao.update(this);
//    }
//
//
//    public long getMId() {
//        return this.mId;
//    }
//
//    public void setMId(long mId) {
//        this.mId = mId;
//    }
//
//    /** called by internal mechanisms, do not call yourself. */
//    @Generated(hash = 1578765116)
//    public void __setDaoSession(DaoSession daoSession) {
//        this.daoSession = daoSession;
//        myDao = daoSession != null ? daoSession.getLyricDao() : null;
//    }
//}
