package com.example.mohamadreza.musicmediaplayer.model;

public class Artist {

    private String mTitle;

    public Artist(String title) {
        mTitle = title;
    }

    public String getTitle() {
        return mTitle;
    }

}
