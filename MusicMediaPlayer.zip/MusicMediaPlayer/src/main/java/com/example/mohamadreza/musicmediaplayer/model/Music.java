package com.example.mohamadreza.musicmediaplayer.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.ToOne;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.DaoException;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Unique;

@Entity
public class Music {

    @Id(autoincrement = true)
    @Unique
    private Long mDbId;
    @Unique
    private long mId;
    private String mTitle;
    private String mAlbum;
    private String mArtist;
    private String srcData;
    private int durationmusic;

    public Music(long id, String title, String album, String artist, String srcData, int durationmusic) {
        mId = id;
        mTitle = title;
        mAlbum = album;
        mArtist = artist;
        this.srcData = srcData;
        this.durationmusic = durationmusic;
    }

    public Music() {
    }

    @Generated(hash = 620855345)
    public Music(Long mDbId, long mId, String mTitle, String mAlbum, String mArtist, String srcData,
            int durationmusic) {
        this.mDbId = mDbId;
        this.mId = mId;
        this.mTitle = mTitle;
        this.mAlbum = mAlbum;
        this.mArtist = mArtist;
        this.srcData = srcData;
        this.durationmusic = durationmusic;
    }

    public int getDurationmusic() {
        return durationmusic;
    }

    public void setDurationmusic(int durationmusic) {
        this.durationmusic = durationmusic;
    }

    public String getSrcData() {
        return srcData;
    }

    public void setSrcData(String srcData) {
        this.srcData = srcData;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getAlbum() {
        return mAlbum;
    }

    public void setAlbum(String album) {
        mAlbum = album;
    }

    public String getArtist() {
        return mArtist;
    }

    public void setArtist(String artist) {
        mArtist = artist;
    }

    public long getMId() {
        return this.mId;
    }

    public void setMId(long mId) {
        this.mId = mId;
    }

    public String getMTitle() {
        return this.mTitle;
    }

    public void setMTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getMAlbum() {
        return this.mAlbum;
    }

    public void setMAlbum(String mAlbum) {
        this.mAlbum = mAlbum;
    }

    public String getMArtist() {
        return this.mArtist;
    }

    public void setMArtist(String mArtist) {
        this.mArtist = mArtist;
    }

    public Long getMDbId() {
        return this.mDbId;
    }

    public void setMDbId(Long mDbId) {
        this.mDbId = mDbId;
    }
}
