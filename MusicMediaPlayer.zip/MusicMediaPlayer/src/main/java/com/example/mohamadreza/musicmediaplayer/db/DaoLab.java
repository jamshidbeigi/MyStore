package com.example.mohamadreza.musicmediaplayer.db;

import com.example.mohamadreza.musicmediaplayer.Dao.App;
import com.example.mohamadreza.musicmediaplayer.model.DaoSession;
import com.example.mohamadreza.musicmediaplayer.model.Music;
import com.example.mohamadreza.musicmediaplayer.model.MusicDao;

import java.util.ArrayList;
import java.util.List;

public class DaoLab {


    private static DaoLab instance;
    private MusicDao mMusicDao;

//    private LyricDao mLyricDao;
//    private LyricLineDao mLyricLineDao;
//    private List<LyricLine> lyrics = new ArrayList<>();


    private DaoLab() {
        DaoSession mDaoSession = (App.getApp()).getDaoSession();
        mMusicDao = mDaoSession.getMusicDao();
//        mLyricDao = mDaoSession.getLyricDao();
//        mLyricLineDao = mDaoSession.getLyricLineDao();
    }

    public static DaoLab getInstance() {
        if (instance == null)
            instance = new DaoLab();
        return instance;
    }


    public List<Music> getFavoritList() {
        return mMusicDao.loadAll();
    }

    public void AddFavorit(Music music) {
        mMusicDao.insert(music);

    }

    public void removeFavorit(Music music) {
        if (mMusicDao.hasKey(music))
            mMusicDao.delete(music);

    }

    public boolean isFavoriut(Music music) {
        return mMusicDao.hasKey(music);
    }
}

